# B2WProductProperties
